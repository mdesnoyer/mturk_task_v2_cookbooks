default['ulimit']['pam_su_template_cookbook'] = nil
default['ulimit']['users'] = Mash.new
default['ulimit']['security_limits_directory'] = '/etc/security/limits.d'
